﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class WordboyUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String wrdid;
    DataSet ds = new DataSet();

    String sql, sql1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            wrdid = Request.QueryString["username"];

            sql = "select wrd_nm,wrd_email,wrd_phno from tbl_wardboy where wrd_id='" + wrdid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
        
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void btn_dt_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tbl_wardboy where wrd_id='" + wrdid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_up_Click(object sender, EventArgs e)
    {
        try
        {
            ds.Tables.Clear();
            con.Open();
            sql1 = "update tbl_wardboy set wrd_nm='" + txt_wd.Text + "',wrd_email='" + txt_wdemail.Text + "',wrd_passwd='" + txt_wdPasswd1.Text + "',wrd_phno='" + txt_wdPh.Text + "' where wrd_id='" + wrdid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}