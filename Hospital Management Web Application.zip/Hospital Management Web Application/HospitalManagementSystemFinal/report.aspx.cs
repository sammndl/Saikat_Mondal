﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class report : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    DataSet ds1 = new DataSet();
    string sql;
    string ptnm;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            ptnm = Request.QueryString["username"];

            sql = "SELECT pt_id,pt_bloodgrp,pt_docDs,pt_pathD FROM tbl_patientDls where pt_id='" + ptnm + "' ";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_pt1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_pt3.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_pt4.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lbl_pt5.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
}