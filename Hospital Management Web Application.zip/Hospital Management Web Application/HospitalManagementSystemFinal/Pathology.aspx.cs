﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Pathology : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string uname,ptn_Name,ptn_i,stf_mail;
    SqlDataReader dr;

    DataSet ds = new DataSet();
    String sql;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            uname = Request.QueryString["username"];

            stf_mail = uname;

            sql = "select stf_nm,stf_email,stf_ph from tbl_stff where stf_email='" + uname + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_patName.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_patEmail.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_patPh.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();

           

        }

        catch (Exception ex)
        {
            throw ex;
        }

        
    }
    protected void btn_patsrc_Click(object sender, EventArgs e)
    {
        try
        {
  
            sql = "SELECT ptn_nm,ptn_id  FROM tbl_patientRg WHERE ptn_id = '" + txt_patsrc.Text + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            ptn_Name = ds.Tables[0].Rows[0].ItemArray[0].ToString();

            ptn_i = ds.Tables[0].Rows[0].ItemArray[1].ToString();

            Response.Redirect("GeneratePatRe.aspx?stf_mail=" + stf_mail + "&ptn_Name=" + ptn_Name + "&ptn_i=" + ptn_i + "");
           
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}