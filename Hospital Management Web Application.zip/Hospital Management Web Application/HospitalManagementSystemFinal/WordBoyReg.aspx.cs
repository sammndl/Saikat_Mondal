﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class WordBoyReg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {
        String id = "WRD" + DateTimeOffset.Now.Day.ToString() + DateTimeOffset.Now.Month.ToString() + DateTimeOffset.Now.Year.ToString() + DateTimeOffset.Now.Hour.ToString() + DateTimeOffset.Now.Minute.ToString() + DateTimeOffset.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
        lbl_wdId.Text = id;
    }
    protected void btn_wdReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql = "Insert into tbl_wardboy(wrd_id,wrd_nm,wrd_email,wrd_passwd,wrd_phno,wrd_addrs,wrd_adhar,wrd_img,wrd_sig)values('" + lbl_wdId.Text + "','" + txt_wd.Text + "','" + txt_wdemail.Text + "','" + txt_wdPasswd2.Text + "','" + txt_wdPh.Text + "','" + txt_wdAddrs.Text + "','" + txt_wdAadhaar.Text + "','" + FilUplPho_wd.FileContent + "','" + FilUpSig_wd.FileContent + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert(' Your Registration is Succesfull')</script");
            }
            else
            {
                Response.Write("<script>alert('Registration is Failed')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}