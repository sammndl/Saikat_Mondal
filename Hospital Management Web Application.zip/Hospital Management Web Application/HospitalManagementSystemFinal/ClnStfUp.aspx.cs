﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ClnStfUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String clnid;
    DataSet ds = new DataSet();

    String sql, sql1;
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();

            clnid = Request.QueryString["username"];

            sql = "select cln_nm,cln_email,cln_passwd,cln_phno from tb_cln where cln_id='" + clnid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();

    }
    protected void btn_clnReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "update tb_cln set cln_nm='" + txt_cln.Text + "',cln_email='" + txt_clnemail.Text + "',cln_passwd='" + txt_clnPasswd2.Text + "',cln_phno='" + txt_clnPh.Text + "'where cln_id='" + clnid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_del_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tb_cln where cln_id='" + clnid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}