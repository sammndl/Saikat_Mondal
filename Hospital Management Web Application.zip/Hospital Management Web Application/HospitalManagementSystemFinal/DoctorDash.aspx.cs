﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class DoctorDash : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string uname;
    SqlDataReader dr;

    DataSet ds = new DataSet();
    DataSet ds1 = new DataSet();

    String sql,sql1;
    string docid, ptid1, ptid2, ptid3, ptid4, ptid5, ptid6;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            uname = Request.QueryString["username"];

            sql = "select doc_id,doc_nm,doc_photo from tbl_DocRg where doc_email='" + uname + "'";
           
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            docid = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            drName.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();

            byte[] bytes = (byte[])ds.Tables[0].Rows[0].ItemArray[2];

            imgDoc.ImageUrl = "data:Image/png;" + bytes;

            String tdate = DateTime.Now.ToUniversalTime().AddMinutes(DateTime.Now.Subtract(DateTime.Now.ToUniversalTime()).TotalMinutes).ToString("yyyy-MM-dd");

            sql1 = "select pt_id,ptn_nm from tbl_patientDls inner join tbl_patientRg on tbl_patientDls.pt_id=tbl_patientRg.ptn_id where tbl_patientDls.pt_doc_id='" + docid + "' and tbl_patientDls.pt_indate='"+ tdate +"'";
            
            SqlDataAdapter adapter1 = new SqlDataAdapter(sql1, con);
            ds1.Tables.Clear();
            adapter1.Fill(ds1);

            ptid1 = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ptid1.Text = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ptname1.Text = ds1.Tables[0].Rows[0].ItemArray[1].ToString();

            ptid2 = ds1.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_ptid2.Text = ds1.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_ptname2.Text = ds1.Tables[0].Rows[1].ItemArray[1].ToString();

            ptid3 = ds1.Tables[0].Rows[2].ItemArray[0].ToString();
            lbl_ptid3.Text = ds1.Tables[0].Rows[2].ItemArray[0].ToString();
            lbl_ptname3.Text = ds1.Tables[0].Rows[2].ItemArray[1].ToString();

            ptid4 = ds1.Tables[0].Rows[3].ItemArray[0].ToString();
            lbl_ptid4.Text = ds1.Tables[0].Rows[3].ItemArray[0].ToString();
            lbl_ptname4.Text = ds1.Tables[0].Rows[3].ItemArray[1].ToString();

            ptid5 = ds1.Tables[0].Rows[4].ItemArray[0].ToString();
            lbl_ptid5.Text = ds1.Tables[0].Rows[4].ItemArray[0].ToString();
            lbl_ptname5.Text = ds1.Tables[0].Rows[4].ItemArray[1].ToString();

            ptid6 = ds1.Tables[0].Rows[5].ItemArray[0].ToString();
            lbl_ptid6.Text = ds1.Tables[0].Rows[5].ItemArray[0].ToString();
            lbl_ptname6.Text = ds1.Tables[0].Rows[5].ItemArray[1].ToString();

        }

        catch (Exception ex)
        {
            Console.Write(ex);
        }
        con.Close();
    }
    protected void btn_gen1_Click(object sender, EventArgs e)
    {

        if(lbl_ptid1.Text != null){
        Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid1 +"");
        }
    }
    protected void btn_gen2_Click(object sender, EventArgs e)
    {
        if (lbl_ptid2.Text != null)
        {
            Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid2 + "");
        }
    }
    protected void btn_gen3_Click(object sender, EventArgs e)
    {
        if (lbl_ptid3.Text != null)
        {
            Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid3 + "");
        }
    }
    protected void btn_gen4_Click(object sender, EventArgs e)
    {
        if (lbl_ptid4.Text != null)
        {
            Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid4 + "");
        }
    }
    protected void btn_gen5_Click(object sender, EventArgs e)
    {
        if (lbl_ptid5.Text != null)
        {
            Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid5 + "");
        }
    }
    protected void btn_gen6_Click(object sender, EventArgs e)
    {
        if (lbl_ptid6.Text != null)
        {
            Response.Redirect("Testpage.aspx?docid=" + docid + "&ptid=" + ptid6 + "");
        }
    }
}