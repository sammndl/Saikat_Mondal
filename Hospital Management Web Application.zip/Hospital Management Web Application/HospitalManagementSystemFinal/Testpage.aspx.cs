﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Testpage : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string docid,ptid;
    SqlDataReader dr;

    DataSet ds = new DataSet();
    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();
    DataSet ds3 = new DataSet();

    String sql,sql1,sql2,sql3;

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();

            docid = Request.QueryString["docid"];
            ptid = Request.QueryString["ptid"];

            DateTime td = DateTime.Now;
            String tds = "";

            tds = td.ToString("yyyy'-'MM'-'dd");


            sql = "SELECT doc_nm,doc_email,doc_ph,doc_expt  FROM tbl_DocRg WHERE doc_id = '"+docid+"'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lblTest_DocName.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lblTest_Docemail.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lblTest_Docph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lblTest_docSp.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();


            sql1 = "SELECT ptn_nm,ptn_email,ptn_hmph,ptn_gen,ptn_addr  FROM tbl_patientRg WHERE ptn_id = '" + ptid + "'";

            SqlDataAdapter adapter1 = new SqlDataAdapter(sql1, con);
            ds1.Tables.Clear();
            adapter1.Fill(ds1);

            lblTest_patnm.Text = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
            lblTest_ptemail.Text = ds1.Tables[0].Rows[0].ItemArray[1].ToString();
            lblTest_ptPh.Text = ds1.Tables[0].Rows[0].ItemArray[2].ToString();
            lblTest_ptsex.Text = ds1.Tables[0].Rows[0].ItemArray[3].ToString();
            lblTest_ptadrs.Text = ds1.Tables[0].Rows[0].ItemArray[4].ToString();
            lblTest_ptdate.Text = tds.ToString();

            sql2 = "SELECT pt_pathD,pt_bloodgrp,pt_docDs FROM tbl_patientDls WHERE pt_id = '" + ptid + "'";

            SqlDataAdapter adapter2 = new SqlDataAdapter(sql2, con);
            ds2.Tables.Clear();
            adapter2.Fill(ds2);

            lbl_rept.Text = ds2.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_bdgrp.Text = ds2.Tables[0].Rows[0].ItemArray[1].ToString();
            txtTest_doc.Text = ds2.Tables[0].Rows[0].ItemArray[3].ToString();
        }

        catch (Exception ex)
        {
            Console.Write(ex);
        }
        con.Close();

    }
    protected void btn_testGen_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql = "update tbl_patientDls set pt_docDs='" + txtTest_doc.Text + "',pt_indate='" + txt_nxtd.Text + "' where pt_id='" + ptid + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Report Complete')</script");
            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Console.Write(ex.Message);
        }
        con.Close();
    }
}