﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class ClnStfReg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {
        String id = "CLN" + DateTimeOffset.Now.Day.ToString() + DateTimeOffset.Now.Month.ToString() + DateTimeOffset.Now.Year.ToString() + DateTimeOffset.Now.Hour.ToString() + DateTimeOffset.Now.Minute.ToString() + DateTimeOffset.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
        lbl_clnId.Text = id;
    }
    protected void btn_clnReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql = "Insert into tb_cln(cln_id,cln_nm,cln_email,cln_passwd,cln_phno,cln_addrs,cln_adhar,cln_img,cln_sig)values('" + lbl_clnId.Text + "','" + txt_cln.Text + "','" + txt_clnemail.Text + "','" + txt_clnPasswd2.Text + "','" + txt_clnPh.Text + "','" + txt_clnRAddrs.Text + "','" + txt_clnAadhaar.Text + "','" + FilUplPho_cln.FileContent + "','" + FilUpSig_cln.FileContent + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert(' Your Registration is Succesfull')</script");
            }
            else
            {
                Response.Write("<script>alert('Registration is Failed')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}