﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Guard : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "SELECT grd_nm,grd_email  FROM tbl_guard ";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_grdName1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_grdEmail1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_grdName2.Text = ds.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_grdEmail2.Text = ds.Tables[0].Rows[1].ItemArray[1].ToString();
            lbl_grdName3.Text = ds.Tables[0].Rows[2].ItemArray[0].ToString();
            lbl_grdEmail3.Text = ds.Tables[0].Rows[2].ItemArray[1].ToString();
            lbl_grdName4.Text = ds.Tables[0].Rows[3].ItemArray[0].ToString();
            lbl_wordbyEmail4.Text = ds.Tables[0].Rows[3].ItemArray[1].ToString();
            lbl_grdName5.Text = ds.Tables[0].Rows[4].ItemArray[0].ToString();
            lbl_grdEmail5.Text = ds.Tables[0].Rows[4].ItemArray[1].ToString();
            lbl_grdName6.Text = ds.Tables[0].Rows[5].ItemArray[0].ToString();
            lbl_grdEmail6.Text = ds.Tables[0].Rows[5].ItemArray[1].ToString();
            

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}