﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class NursesReg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {

        String id = "NRS" + DateTimeOffset.Now.Day.ToString() + DateTimeOffset.Now.Month.ToString() + DateTimeOffset.Now.Year.ToString() + DateTimeOffset.Now.Hour.ToString() + DateTimeOffset.Now.Minute.ToString() + DateTimeOffset.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
        lbl_nrsId.Text = id;

    }
    protected void btn_nrsReg_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "Insert into tbl_nrsRg(nrs_id,nrs_nm,nrs_email,nrs_passwd,nrs_mobile,nrs_resPh,nrs_mdrg,nrs_rsaddr,nrs_prtadrs,nrs_dob,nrs_adhar,nrs_exprt,nrs_mdeicalClg,nrs_yop,nrs_img,nrs_sig)values('" + lbl_nrsId.Text + "','" + txtnrs.Text + "','" + txt_nrsemail.Text + "','" + txt_nrsPasswd2.Text + "','" + txt_nrsPh.Text + "','" + txt_nrsRph.Text + "','" + txt_nrsRegNo.Text + "','" + txtnrsRAddrs.Text + "','" + txtnrsAddrs.Text + "','" + txtnrsDOB.Text + "','" + txtnrsAadhaar.Text + "','" + drp_nrsOption.SelectedItem.Text + "','" + txt_nrsCol.Text + "','" + txt_nrsdate.Text + "','" + FileUploadPhotonrs.FileContent + "','" + FileUploadSignaturenrs.FileContent + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Registration is Complete')</script");
            }
            else
            {
                Response.Write("<script>alert('Registration Failed')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}