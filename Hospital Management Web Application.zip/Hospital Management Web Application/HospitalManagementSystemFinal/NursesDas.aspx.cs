﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class NursesDas : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "SELECT nrs_nm,nrs_email  FROM tbl_nrsRg";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nrsName1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_nrsEmail1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_nrsName2.Text = ds.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_nrsEmail2.Text = ds.Tables[0].Rows[1].ItemArray[1].ToString();
            lbl_nrsName3.Text = ds.Tables[0].Rows[2].ItemArray[0].ToString();
            lbl_nrsEmail3.Text = ds.Tables[0].Rows[2].ItemArray[1].ToString();
            lbl_nrsName4.Text = ds.Tables[0].Rows[3].ItemArray[0].ToString();
            lbl_nrsEmail4.Text = ds.Tables[0].Rows[3].ItemArray[1].ToString();



        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}