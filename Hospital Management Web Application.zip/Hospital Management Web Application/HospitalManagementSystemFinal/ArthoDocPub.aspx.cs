﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ArthoDocPub : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql,sql1;
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "SELECT doc_nm,doc_email  FROM tbl_DocRg WHERE doc_expt = 'Orthopidict' AND doc_id = 'DOC204201895816317'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_arName1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_Email1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();

            sql1 = "SELECT doc_nm,doc_email  FROM tbl_DocRg WHERE doc_expt = 'Orthopidict' AND doc_id = 'DOC204201810148609'";

            SqlDataAdapter adapter1 = new SqlDataAdapter(sql1, con);
            ds.Tables.Clear();
            adapter1.Fill(ds);

            lbl_arName2.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_Email2.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
           
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}