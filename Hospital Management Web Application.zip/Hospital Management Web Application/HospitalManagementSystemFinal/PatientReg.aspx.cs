﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class PatientReg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;
    protected void Page_Load(object sender, EventArgs e)
    {

        String id = "PTN" + DateTimeOffset.Now.Day.ToString() + DateTimeOffset.Now.Month.ToString() + DateTimeOffset.Now.Year.ToString() + DateTimeOffset.Now.Hour.ToString() + DateTimeOffset.Now.Minute.ToString() + DateTimeOffset.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
        lbl_ptnId.Text = id;

    }
    protected void btn_Psubmit_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "Insert into tbl_patientRg(ptn_id,ptn_nm,ptn_reltn,ptn_gen,ptn_dob,ptn_addr,ptn_city,ptn_nation,ptn_hmph,ptn_ofph,ptn_cntph,ptn_email,ptn_psswd,ptn_job,ptn_adhr)values('" + lbl_ptnId.Text + "','" + txt_Pname.Text + "','" + txt_Prelation.Text + "','" + rbtn_Pgender.Text + "','" + txt_Pdob.Text + "','" + txt_Paddress.Text + "','" + txt_Pcity.Text + "','" + txt_Pnation.Text + "','" + txt_PHphone.Text + "','"+ txt_Poffice.Text +"','" + txt_PCnumber.Text + "','" + txt_Pemail.Text + "','" + txt_Pepasswd2.Text + "','" + drp_Poccupation.Text + "','" + txt_Paadhaar.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Your Registration is Successfull')</script");
            }
            else
            {
                Response.Write("<script>alert('Registration Failed')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
    protected void btn_Pclear_Click(object sender, EventArgs e)
    {

        
        txt_Pname.Text = "";
        txt_Prelation.Text = "";
        rbtn_Pgender.Text = "";
        txt_Pdob.Text = "";
        txt_Paddress.Text = "";
        txt_Pcity.Text = "";
        txt_Pnation.Text = "";
        txt_PHphone.Text = "";
        txt_Poffice.Text = "";
        txt_PCnumber.Text = "";
        txt_Pemail.Text = "";
        txt_Pepasswd1.Text = "";
        txt_Pepasswd2.Text = "";
        drp_Poccupation.Text = "";
        txt_Paadhaar.Text = "";

    }
}