﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class StuffReg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {

        String id = "STUFF" + DateTimeOffset.Now.Day.ToString() + DateTimeOffset.Now.Month.ToString() + DateTimeOffset.Now.Year.ToString() + DateTimeOffset.Now.Hour.ToString() + DateTimeOffset.Now.Minute.ToString() + DateTimeOffset.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
        lbl_stfId.Text = id;

    }
    protected void btn_stfReg_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "Insert into tbl_stff(stf_id,stf_nm,stf_email,stf_passwd,stf_ph,stf_Rph,stf_Raddrs,stf_Paddrs,stf_dob,stf_adhar,stf_img,stf_sig)values('" + lbl_stfId.Text + "','" + txt_stf.Text + "','" + txt_stfemail.Text + "','" + txt_stfPasswd2.Text + "','" + txt_stfPh.Text + "','" + txt_stfRph.Text + "','" + txt_stfRAddrs.Text + "','" + txt_stfAddrs.Text + "','" +txt_stfDOB.Text+ "','"+txt_stfAadhaar.Text+"','" + FilUplPho_stf.FileContent + "','" + FilUpSig_stf.FileContent + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Registration Succesfull')</script");
            }
            else
            {
                Response.Write("<script>alert('Registration Failed')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}