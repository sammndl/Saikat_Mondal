﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class GyneDocPub : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {


        try
        {
            con.Open();
            sql = "SELECT doc_nm,doc_email  FROM tbl_DocRg WHERE doc_expt = 'Gynecologist'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_Gnyname1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_GnyEmail1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_Gnyname2.Text = ds.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_GnyEmail2.Text = ds.Tables[0].Rows[1].ItemArray[1].ToString();
            

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}