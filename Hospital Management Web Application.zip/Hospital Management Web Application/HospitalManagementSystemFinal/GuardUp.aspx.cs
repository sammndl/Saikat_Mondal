﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class GuardUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String grdid;
    DataSet ds = new DataSet();

    String sql, sql1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            grdid = Request.QueryString["username"];

            sql = "select grd_nm,grd_email,grd_phno from tbl_guard where grd_id='" + grdid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void btn_gdReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "update tbl_guard set grd_nm='" + txt_gd.Text + "',grd_email='" + txt_gdemail.Text + "',grd_passwd='" + txt_gdPasswd1.Text + "',grd_phno='" + txt_gdPh.Text + "'where grd_id='" + grdid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_d_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tbl_guard where grd_id='" + grdid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}