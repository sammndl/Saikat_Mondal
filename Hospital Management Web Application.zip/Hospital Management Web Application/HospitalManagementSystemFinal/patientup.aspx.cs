﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;;

public partial class patientup : System.Web.UI.Page
{
     SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String ptnid;
    DataSet ds = new DataSet();

    String sql, sql1;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

           ptnid  = Request.QueryString["username"];

           sql = "select ptn_nm,ptn_addr,ptn_cntph,ptn_email from tbl_patientRg where ptn_id='" + ptnid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_ptnId.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_add.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void btn_Psubmit_Click(object sender, EventArgs e)
    {
         try
        {
            con.Open();
            sql1 = "update tbl_patientRg set ptn_nm='"+txt_Pname.Text+"',ptn_addr='"+txt_Paddress.Text+"',ptn_cntph='"+txt_PCnumber.Text+"',ptn_email='"+txt_Pemail.Text+"',ptn_psswd='"+txt_Pepasswd1.Text+"'where ptn_id='"+ptnid+"'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
protected void  btn_de_Click(object sender, EventArgs e)
{

     try
        {
            con.Open();
            sql1 = "delete from tbl_patientRg where ptn_id='"+ptnid+"'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
}
}