﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class AdminPage : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string uname;
    SqlDataReader dr;

    DataSet ds = new DataSet();

    String sql,sql1,sql2,sql3,sql4,sql5,sql6,sql7,sql8;
    string docid, nrsid, stuffid, patientid, wordboyid, gurdid, clnid;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            uname = Request.QueryString["username"];

            sql = "select ad_nm,ad_mail,ad_ph from tbl_admin where ad_id='" + uname + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_mail.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
        }
        catch (Exception ex)
        {
            Console.Write(ex);
        }
        con.Close();
    }
    protected void btn_docup_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();


            string sql = "select doc_id from tbl_DocRg where doc_id='" + txt_docup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                docid = dr.GetValue(0).ToString();

            }
            if (docid == txt_docup.Text)
            {

                Response.Redirect("DocUp.aspx?username=" + docid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Doctor Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }

    }
    protected void btn_nrsup_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();


            string sql = "select nrs_id from tbl_nrsRg where nrs_id='" + txt_nrsup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                nrsid = dr.GetValue(0).ToString();

            }
            if (nrsid == txt_nrsup.Text)
            {

                Response.Redirect("NursesUp.aspx?username=" + nrsid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Nurses Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }

    }
    protected void btn_stfup_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select stf_id from tbl_stff where stf_id='" + txt_stfup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                stuffid = dr.GetValue(0).ToString();

            }
            if (stuffid == txt_stfup.Text)
            {

                Response.Redirect("StuffUp.aspx?username=" + stuffid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Stuff Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
    protected void btn_patup_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select ptn_id from tbl_patientRg where ptn_id='" + txt_patup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                patientid = dr.GetValue(0).ToString();

            }
            if (patientid == txt_patup.Text)
            {

                Response.Redirect("patientup.aspx?username=" + patientid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Patient Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
    protected void btn_wdup_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select wrd_id from tbl_wardboy where wrd_id='" + txt_wdup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                wordboyid = dr.GetValue(0).ToString();

            }
            if (wordboyid == txt_wdup.Text)
            {

                Response.Redirect("WordboyUp.aspx?username=" + wordboyid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong WordBoy Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
    protected void btn_gdup_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select grd_id from tbl_guard where grd_id='" + txt_gdup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                gurdid = dr.GetValue(0).ToString();

            }
            if (gurdid == txt_gdup.Text)
            {

                Response.Redirect("GuardUp.aspx?username=" + gurdid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Guard Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
    protected void btn_clnup_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select cln_id from tb_cln where cln_id='" + txt_clnup.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                clnid = dr.GetValue(0).ToString();

            }
            if (clnid == txt_clnup.Text)
            {

                Response.Redirect("ClnStfUp.aspx?username=" + clnid + "");


            }
            else
            {
                Response.Write("<script>alert('Wrong Clean Stuff Id!')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
    protected void btn_admin_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUp.aspx?username=" + uname + "");
    }
}