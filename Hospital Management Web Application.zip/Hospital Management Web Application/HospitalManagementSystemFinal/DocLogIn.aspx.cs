﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class DocLogIn : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string password = null, username;
    SqlDataReader dr;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_DocLogIn_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();


            string sql = "select doc_email,doc_pass from tbl_DocRg where doc_email='" + txt_DocID.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                username = dr.GetValue(0).ToString();
                password = dr.GetValue(1).ToString();

            }
            if (username == txt_DocID.Text && password == txt_DocPassword.Text)
            {

                Response.Write("<script>alert('Login Successfull')</script");

                Response.Redirect("DoctorDash.aspx?username=" + username + "");

            }

            else
            {
                Response.Write("<script>alert('Login Faild')</script");

            }

        }

        catch (Exception ex)
        {
            throw ex;
        }

        finally
        {
            con.Close();

        }
    }
}