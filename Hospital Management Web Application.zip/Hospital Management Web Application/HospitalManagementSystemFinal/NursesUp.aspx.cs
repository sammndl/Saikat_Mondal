﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class NursesUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String nrsid;
    DataSet ds = new DataSet();

    String sql, sql1;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            nrsid = Request.QueryString["username"];

            sql = "select nrs_nm,nrs_email,nrs_mobile,nrs_rsaddr,nrs_exprt,nrs_mdeicalClg,nrs_yop from tbl_nrsRg where nrs_id='" + nrsid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lbl_ad.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
            lbl_ex.Text = ds.Tables[0].Rows[0].ItemArray[4].ToString();
            lbl_clg.Text = ds.Tables[0].Rows[0].ItemArray[5].ToString();
            lbl_yo.Text = ds.Tables[0].Rows[0].ItemArray[6].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void btn_nrsReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "update tbl_nrsRg set nrs_nm='" + txtnrs.Text + "',nrs_email='" + txt_nrsemail.Text + "',nrs_passwd='" + txt_nrsPasswd1.Text + "',nrs_mobile='" + txt_nrsPh.Text + "',nrs_rsaddr='" + txtnrsAddrs.Text + "',nrs_exprt='" + drp_nrsOption.SelectedItem.Text + "',nrs_mdeicalClg='" + txt_nrsCol.Text + "',nrs_yop='" + txt_nrsdate.Text + "'where nrs_id='" + nrsid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_Del_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tbl_nrsRg where nrs_id='" + nrsid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}