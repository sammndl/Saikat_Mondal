﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ProfileDefault : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    DataSet ds1 = new DataSet();
    string sql, sql1,sql2;
    string username;
    string ptnm;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            username = Request.QueryString["username"];

            sql = "SELECT ptn_id,ptn_nm,ptn_email  FROM tbl_patientRg where ptn_email='" + username + "' ";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            ptnm = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ptnm.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ptmail.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        con.Close();

    }
    protected void btn_srh_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql1 = "SELECT doc_nm,doc_id  FROM tbl_DocRg WHERE doc_expt = '" + drp_stdoc.SelectedItem.Text + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql1, con);
            ds1.Tables.Clear();
            adapter.Fill(ds1);

           

                lbl_doc1.Text = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
                lbl_id1.Text = ds1.Tables[0].Rows[0].ItemArray[1].ToString();
            
                lbl_doc2.Text = ds1.Tables[0].Rows[1].ItemArray[0].ToString();
                lbl_id2.Text = ds1.Tables[0].Rows[1].ItemArray[1].ToString();
            
                lbl_doc3.Text = ds1.Tables[0].Rows[2].ItemArray[0].ToString();
                lbl_id3.Text = ds1.Tables[0].Rows[2].ItemArray[1].ToString();
            
         
            
                lbl_doc4.Text = ds1.Tables[0].Rows[3].ItemArray[0].ToString();
                lbl_id4.Text = ds1.Tables[0].Rows[3].ItemArray[1].ToString();

        }
        catch (Exception ex)
        {
            Console.Write(ex);
           // throw ex;
        }
        con.Close();
    }

    protected void btn_sub_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql2 = "Insert into tbl_patientDls(pt_id,pt_doc_id,pt_indate)values('"+ ptnm +"','" + txt_doc.Text + "','"+ txt_time.Text +"')";
            SqlCommand cmd = new SqlCommand(sql2, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Successfully Booked')</script");
            }
            else
            {
                Response.Write("<script>alert('Failed to Book')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_view_Click(object sender, EventArgs e)
    {
        Response.Redirect("report.aspx?username=" + ptnm + "");
    }
}