﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class GeneratePatRe : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);

    string stf_mail,ptn_Name,ptn_d;
    SqlDataReader dr;

    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();
    DataSet ds3 = new DataSet();
    
    String sql1,sql2,sql3,sql4;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            stf_mail = Request.QueryString["stf_mail"];
            ptn_Name = Request.QueryString["ptn_Name"];
            ptn_d = Request.QueryString["ptn_i"];

            sql1 = "select stf_nm,stf_email,stf_ph from tbl_stff where stf_email='" + stf_mail + "'";

            SqlDataAdapter adapter1 = new SqlDataAdapter(sql1, con);
            ds1.Tables.Clear();
            adapter1.Fill(ds1);

            lbl_GnName.Text = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_patEmail.Text = ds1.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_patPh.Text = ds1.Tables[0].Rows[0].ItemArray[2].ToString();

            sql2 = "select ptn_nm,ptn_ofph,ptn_email from tbl_patientRg where ptn_id='" + ptn_d + "'";

            SqlDataAdapter adapter2 = new SqlDataAdapter(sql2, con);
            ds2.Tables.Clear();
            adapter2.Fill(ds2);

            lbl_gnpname.Text = ds2.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_gnpemail.Text = ds2.Tables[0].Rows[0].ItemArray[1].ToString();
            lib_gnpNo.Text = ds2.Tables[0].Rows[0].ItemArray[2].ToString();


            sql4 = "select pt_docDs from tbl_patientDls where pt_id='" + ptn_d + "'";

            SqlDataAdapter adapter3 = new SqlDataAdapter(sql4, con);
            ds3.Tables.Clear();
            adapter3.Fill(ds3);

            lbl_docD.Text = ds3.Tables[0].Rows[0].ItemArray[0].ToString();
        }

        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void btn_gnpSub_Click(object sender, EventArgs e)
    {
        try
        {
            sql3 = "update tbl_patientDls set pt_pathD='"+txt_gnpreport.Text+"',pt_bloodgrp='"+drp_bldgrp.Text+"' where pt_id='"+ptn_d+"'";
            SqlCommand cmd = new SqlCommand(sql3, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('value inserted')</script");
            }
            else
            {
                Response.Write("<script>alert('Failed To Insert')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}