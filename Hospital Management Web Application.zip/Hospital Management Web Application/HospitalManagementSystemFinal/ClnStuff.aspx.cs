﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ClnStuff : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
    SqlDataAdapter dr;
    DataSet ds = new DataSet();
    string sql;

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "SELECT cln_nm,cln_email FROM tb_cln";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_clnName1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_clnEmail1.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_clnName2.Text = ds.Tables[0].Rows[1].ItemArray[0].ToString();
            lbl_clnEmail2.Text = ds.Tables[0].Rows[1].ItemArray[1].ToString();
            lbl_clnName3.Text = ds.Tables[0].Rows[2].ItemArray[0].ToString();
            lbl_clnEmail3.Text = ds.Tables[0].Rows[2].ItemArray[1].ToString();
            lbl_clnName4.Text = ds.Tables[0].Rows[3].ItemArray[0].ToString();
            lbl_clnEmail4.Text = ds.Tables[0].Rows[3].ItemArray[1].ToString();
            lbl_clnName5.Text = ds.Tables[0].Rows[4].ItemArray[0].ToString();
            lbl_clnEmail5.Text = ds.Tables[0].Rows[4].ItemArray[1].ToString();
            lbl_clnName6.Text = ds.Tables[0].Rows[5].ItemArray[0].ToString();
            lbl_clnEmail6.Text = ds.Tables[0].Rows[5].ItemArray[1].ToString();

        }
        catch (Exception ex)
        {
            Console.Write(ex.Message);
        }
        con.Close();

    }
}