﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class update : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    DataSet ds = new DataSet();

    String sql;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_set_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            sql = "UPDATE tbl_admin SET ad_passwd='" + Textpass.Text + "'WHERE ad_id='" + txt_up.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();

    }
}