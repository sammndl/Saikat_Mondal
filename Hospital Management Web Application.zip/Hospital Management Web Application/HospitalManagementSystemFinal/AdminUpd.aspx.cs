﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class AdminUpd : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String adid;
    DataSet ds = new DataSet();

    String sql;
    String sql1;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            adid = Request.QueryString["username"];

            sql = "select ad_nm,ad_mail,ad_passwd,ad_ph from tbl_admin where ad_id='" + adid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            TextBox1.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            TextBox2.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            TextBox4.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1="UPDATE tbl_admin SET ad_nm='"+TextBox1.Text+"',ad_mail='"+TextBox2.Text+"',ad_passwd='"+TextBox3.Text+"',ad_ph='"+TextBox4.Text+"' WHERE ad_id='" + adid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}