﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class DocUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String docid;
    DataSet ds = new DataSet();

    String sql,sql1;
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            con.Open();

            docid = Request.QueryString["username"];

            sql = "select doc_nm,doc_email,doc_pass,doc_ph,doc_raddrs,doc_expt,doc_mdclg,doc_yop from tbl_DocRg where doc_id='" + docid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_pass.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
            lbl_add.Text = ds.Tables[0].Rows[0].ItemArray[4].ToString();
            lbl_gen.Text = ds.Tables[0].Rows[0].ItemArray[5].ToString();
            lbl_clg.Text = ds.Tables[0].Rows[0].ItemArray[6].ToString();
            lbl_y.Text = ds.Tables[0].Rows[0].ItemArray[7].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();

    }
    protected void btn_del_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tbl_DocRg where doc_id='"+ docid +"'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Delete Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_up_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "update tbl_DocRg set doc_nm='" + txtDocnm.Text + "',doc_email='" + txt_Docemail.Text + "',doc_pass='" + txt_DocPasswd1.Text + "',doc_ph='" + txt_DocPh.Text + "',doc_raddrs='" + txtRAddrs.Text + "',doc_expt='" + drp_DocOption.SelectedItem.Text + "',doc_mdclg='" + txt_DocCol.Text + "',doc_yop='" + txt_date.Text + "'where doc_id='" + docid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}