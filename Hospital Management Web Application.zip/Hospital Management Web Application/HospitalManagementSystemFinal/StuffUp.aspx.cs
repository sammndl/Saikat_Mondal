﻿using System;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class StuffUp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
    SqlDataReader dr;
    String stfid;
    DataSet ds = new DataSet();

    String sql, sql1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con.Open();

           stfid  = Request.QueryString["username"];

           sql = "select stf_nm,stf_email,stf_ph,stf_Raddrs from tbl_stff where stf_id='" + stfid + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            ds.Tables.Clear();
            adapter.Fill(ds);

            lbl_nm.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            lbl_ml.Text = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            lbl_ph.Text = ds.Tables[0].Rows[0].ItemArray[2].ToString();
            lbl_add.Text = ds.Tables[0].Rows[0].ItemArray[3].ToString();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
        con.Close();
    }
    protected void btn_stfReg_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "update tbl_stff set stf_nm='"+txt_stf.Text+"',stf_email='"+txt_stfemail.Text+"',stf_passwd='"+txt_stfPasswd1.Text+"',stf_ph='"+txt_stfPh.Text+"',stf_Raddrs='"+txt_stfRAddrs.Text+"' where stf_id='"+stfid+"'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
    protected void btn_del_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            sql1 = "delete from tbl_stff where stf_id='" + stfid + "'";
            SqlCommand cmd = new SqlCommand(sql1, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Update Complete')</script");

            }
            else
            {
                Response.Write("<script>alert('Error')</script");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        con.Close();
    }
}